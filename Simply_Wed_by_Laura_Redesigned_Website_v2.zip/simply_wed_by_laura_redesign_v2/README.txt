SIMPLY WED BY LAURA — REDESIGNED WEBSITE

Upload index.html and the entire assets folder to your GitHub Pages repository. Keep the folder named assets beside index.html.

The redesign uses existing Simply Wed by Laura branded imagery from your saved files: wedding expo portrait/booth, wedding-officiant portrait graphic, and preparation/workspace imagery.
